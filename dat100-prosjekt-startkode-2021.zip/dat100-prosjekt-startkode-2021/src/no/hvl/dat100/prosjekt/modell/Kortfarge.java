package no.hvl.dat100.prosjekt.modell;

public enum Kortfarge {
	
	Hjerter, Ruter, Klover, Spar
	
}
